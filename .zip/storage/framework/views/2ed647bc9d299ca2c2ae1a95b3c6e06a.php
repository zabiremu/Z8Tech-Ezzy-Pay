<?php $__env->startSection('content'); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Saira&display=swap" rel="stylesheet">

    <style>
        .divider {
            position: relative;
            height: 1px;
            display: block;
            background-color: rgba(0, 0, 0, 0.37);
            margin-bottom: 30px;
        }
    </style>



    <div class="notch-clear"></div>
    <div class="pt-5 mt-4"></div>
    <div class="card card-style overflow-visible mt-5" style="margin-top:100px !important">
        <div class="mt-n5"></div>
        <img src="<?php echo e(Auth::user()->image ?? ''); ?>" alt="img" width="180" class="mx-auto mt-n5 shadow-l"
            style="border-radius: 10px !important;">
        <!-- <h1 class="color-theme text-center font-30 mb-0 margin">Fortune01</h1> -->
        <p class="text-center font-11"></p>



        <div class="content mt-0 mb-2">

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1">User Name</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1 "> <?php echo e(Auth::user()->username ?? ''); ?> </h4>
                </div>
            </a>
            <div class="divider my-2 opacity-50"></div>

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1 k">First Name</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1 "><?php echo e(Auth::user()->first_name); ?> </h4>
                </div>
            </a>
            <div class="divider my-2 opacity-50"></div>

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1 ">Last Name</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1 "> <?php echo e(Auth::user()->last_name); ?> </h4>
                </div>
            </a>
            <div class="divider my-2 opacity-50"></div>

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1 ">Email</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1 "> <?php echo e(Auth::user()->email); ?> </h4>
                </div>
            </a>
            <div class="divider my-2 opacity-50"></div>

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1 ">Phone</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1 "> <?php echo e(Auth::user()->phone_no); ?></h4>
                </div>
            </a>
            <div class="divider my-2 opacity-50"></div>

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1 ">Country</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1 "><?php echo e(Auth::user()->country); ?> </h4>
                </div>
            </a>
            <div class="divider my-2 opacity-50"></div>

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1  ">Address</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1 "><?php echo e(Auth::user()->address); ?> </h4>
                </div>
            </a>
            <div class="divider my-2 opacity-50"></div>

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1  ">Sponsor Me</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1 ">
                        <?php if(Auth::user()->sponsor): ?>
                            <?php echo e(Auth::user()->sponsor); ?>

                        <?php else: ?>
                            <span class="text-danger"> no sponsor</span>
                        <?php endif; ?>
                    </h4>
                </div>
            </a>
            <div class="divider my-2 opacity-50"></div>

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1 ">My Rank</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1"> </h4>
                </div>
            </a>
            <div class="divider my-2 opacity-50"></div>

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1 color-green-dark ">Package</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1 color-green-dark">
                        <?php if(Auth::user()->is_approved == 1): ?>
                            Active
                        <?php else: ?>
                            <span class="text-danger"> In-Active</span>
                        <?php endif; ?>
                    </h4>
                </div>
            </a>

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1  ">Nid Image 1</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1 ">
                        <?php if(Auth::user()->nid1): ?>
                            <img src="<?php echo e(Auth::user()->nid1); ?>" alt="" width="100px">
                        <?php else: ?>
                            <span class="text-danger"> no nid</span>
                        <?php endif; ?>
                    </h4>
                </div>
            </a>

            <a href="javascript:;" class="d-flex py-1">
                <div class="align-self-center ps-1">
                    <h5 class="pt-1 mb-n1  ">Nid Image 2</h5>
                </div>
                <div class="align-self-center ms-auto text-end">
                    <h4 class="pt-1 mb-n1 ">
                        <?php if(Auth::user()->nid2): ?>
                            <img src="<?php echo e(Auth::user()->nid2); ?>" alt="" width="100px">
                        <?php else: ?>
                            <span class="text-danger"> no nid</span>
                        <?php endif; ?>
                    </h4>
                </div>
            </a>

            <div class="divider my-2 opacity-50"></div>


            <a href="<?php echo e(route('users.update.profile')); ?>">
                <button class="btn btn-full rounded-xs text-uppercase font-700 w-100 btn-s mt-4"
                    style="margin-bottom:15px;background: #6236ff;" type="button">Information Update</button>
            </a>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Personal-Project\Z8Tech-Ezzy-Pay\resources\views/users/profile/index.blade.php ENDPATH**/ ?>