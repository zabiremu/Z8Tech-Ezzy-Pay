<?php $__env->startSection('content'); ?>
    <?php
        $wallet = App\Models\Wallet::where('user_id', Auth::user()->id)->first();
        $userId= Auth::user();
        $user= App\Models\User::where('id',$userId->id)->first();
    ?>
    <div class="card overflow-visible card-style" style="margin-top: 70px;">
        <div class="content mb-0">
            <div style="display: flex;justify-content: space-between;">
                <h2> Send Your Balance </h2>
                <h2> <span id="balance_span"></span>৳ <?php echo e($wallet->my_wallet ?? 0.0); ?> </h2>
            </div>

            <form id="send_form" class="demo-animation  m-0" action="<?php echo e(route('users.withDraw.ammount')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-custom form-label form-icon mb-3">
                    <i class="bi font-14"></i>
                    <select class="form-control rounded-xs" id="transfer_sender_ac" name="type"
                        style="font-size: 18px !important;" required>
                        <option value="Ezzy Wallet">Nogod</option>
                    </select>
                    <label for="transfer_sender_ac" class="color-theme"> Select Wallet </label>
                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger" style="color: red"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-custom form-label form-icon mb-3">
                    <i class="bi font-14"></i>
                    <input type="number" class="form-control rounded-xs" name="phone_number" id="transfer_send_amount"
                        placeholder=" Phone number " required  value="<?php echo e($user->phone_no); ?>" />
                    <label for="transfer_send_amount" class="color-theme"> Phone number </label>
                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="form-custom form-label form-icon mb-3">
                    <i class="bi font-14"></i>
                    <input type="number" class="form-control rounded-xs" name="send_amount" id="transfer_send_amount"
                        placeholder="Amount" required />
                    <label for="transfer_send_amount" class="color-theme"> Amount </label>

                </div>
                <?php $__errorArgs = ['send_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger" style="color:red"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                <div class="form-custom form-label form-icon mb-3">
                    <i class="bi font-14"></i>
                    <input type="text" class="form-control rounded-xs" id="_tpin" name="tpin" placeholder="T-PIN"
                        required />
                    <label for="_tpin" class="color-theme"> T-PIN </label>
                    <?php $__errorArgs = ['tpin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="" style="color:red"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>



                <button class="btn btn-full bg-blue-dark rounded-xs text-uppercase font-700 w-100 btn-s mt-4"
                    style="margin-bottom: 20px;"> Send </button>

            </form>

        </div>
    </div>

    <?php $__env->startPush('customJs'); ?>
        <script>
            var receiver = $('#receiver');
            var receiverFname = $('#receiver_fname');
            receiver.on('keyup', function() {


                var value = $(this).val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: '<?php echo e(route('users.get.ajax')); ?>',
                    method: 'POST',
                    data: {
                        key1: value,
                    },
                    success: function(response) {
                        //var data= JSON.stringify(response)
                        receiverFname.val(response)
                    },

                    error: function(xhr, status, error) {
                        console.error(error);
                    },
                });
            })
        </script>

        <script>
            $(document).ready(function() {
                // Cache the elements
                var senderWalletSelect = $('#transfer_sender_ac');
                var receiverIdInput = $('#receiver');
                var receiverFnameInput = $('#receiver_fname');

                // Initially, check the selected option on page load
                checkSelectedOption(senderWalletSelect.val());

                // Attach an event listener to the wallet selection dropdown
                senderWalletSelect.on('change', function() {
                    var selectedWallet = $(this).val();
                    checkSelectedOption(selectedWallet);
                });

                function checkSelectedOption(selectedWallet) {
                    // Check the selected option and set 'required' attribute accordingly
                    if (selectedWallet === 'Ezzy Wallet') {
                        receiverIdInput.prop('required', true);
                        receiverFnameInput.prop('required', true);
                    } else {
                        receiverIdInput.prop('required', false);
                        receiverFnameInput.prop('required', false);
                    }
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Personal-Project\Z8Tech-Ezzy-Pay\resources\views/users/withdraw/withDraw.blade.php ENDPATH**/ ?>